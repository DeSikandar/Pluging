<?php






?>


<form action="" metho="POST">
<input type="hidden" role="uploadcare-uploader" name="image" id="setp"  data-images-only  />
<button type="submit" name="btnsubmit" id="btn1">Save</button>