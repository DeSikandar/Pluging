<input type="button" value="16:9" id="b1">
<input type="button" value="4:3" id="b2">
<input type="button" value="5:4" id="b3">
<input type="button" value="1:1" id="b4">


<canvas id="canvas"  ></canvas>
<form action="" method="POST">
    <input type="hidden" id="img_id" name="img_url">
    <button type="submit" id="btn4" name="btnimgsave" ></button>
</form>
<script type="text/javascript">
    var b1=document.getElementById("b1");
    var b2=document.getElementById("b2");
    var b3=document.getElementById("b3");
    var b4=document.getElementById("b4");
    var setp=document.getElementById("setp");

                $("#b1").click(function(){
                $('#setp').attr('data-crop',b1.value);
                
                });

                $("#b2").click(function(){
                $('#setp').attr('data-crop',b2.value);
                });
                      
                $("#b3").click(function(){
               $('#setp').attr('data-crop',b3.value);
                });
                
                $("#b4").click(function(){
               $('#setp').attr('data-crop',b4.value);
                });
</script>


<?php
if(isset($_POST['btnimgsave']))
{
    global $product;
    $id = $product->get_id();

     $img_url = $_POST['img_url'];
    if (!empty($img_url))
        update_post_meta($id, 'pimg_url', esc_attr($img_url));
    echo "<img src=".$img_url.">";



}



if(isset($_POST['btnsubmit']))
    {
       
	
	



                $url_to_image = $_POST['image'];
                $my_save_dir = plugin_path.'/images/';
                $filename = basename($url_to_image);
               
                
                //$complete_save_loc = $my_save_dir . $filename;
                //$imag =    file_get_contents($url_to_image);
                $complete_save_loc = $my_save_dir . $filename;
             

                
                file_put_contents($complete_save_loc, file_get_contents($url_to_image));

              
                $img2=$_POST['image'];
	
                global $wpdb;

                $table_name = $wpdb->prefix . 'sp2';
               
                $test_text = $filename;
            
            
            
            $wpdb->insert( 
                $table_name, 
                array( 
                    'time' => current_time( 'mysql' ), 
                    
                    'text' => $test_text, 
                ) 
            );
            
    
    }









$image = wp_get_attachment_image_src(get_post_thumbnail_id(),'large');
//echo $image[0];

//echo "This is the file name".$filename;
global $wpdb;
$table_name = $wpdb->prefix . 'sp2';
$res= $wpdb->get_results("SELECT text  FROM $table_name");

//print_r($res[0]->name);
$sd= $res[0]->text;



$complate_url=plugin_url."/Final/images/".$sd;
$testurl=plugin_url."/Final/images/a.jpg";
global $woocommerce, $post;



if(isset($filename))
{
$imgsikandar= plugin_url."/Final/images/".$filename;

}





echo "<img src=# id=imgid >";




$urls=plugin_path."/inc/Insert_image_meta.php";

?>



<script>


        

        var ims='<?php  echo $imgsikandar  ;?>';

        var count1=0;

        if(ims=='')
        {
            count1=1;
        }
        else{
            var img2=loadImage(ims,main);
             img2.setAttribute('crossOrigin','anonymous');
            
            count1=2;
                        

        }
       
      
        
        var c=document.getElementById('canvas');
        var ctx=c.getContext("2d");
        var ig1='<?php echo $image[0]; ?>';

        c.width='<?php echo $image[1];?>';
        c.height='<?php echo $image[2]; ?>';
        var img1=loadImage(ig1,main);
        
      
        img1.setAttribute('crossOrigin','anonymous');
        var x='<?php echo get_post_meta($post->ID,'xvalue',true); ?>';
        var y='<?php echo get_post_meta($post->ID,'yvalue',true); ?>';
        var w='<?php echo get_post_meta($post->ID,'wvalue',true); ?>';
        var h='<?php echo get_post_meta($post->ID,'hvalue',true); ?>';
       

        
       
        
        
        var m=0;
        function loadImage(src,onload)
        {
            var img=new Image();
            img.onload=onload;
            img.src=src;
            img.crossOrigin = "Anonymous";
            return img;
        }
        
        function main()
            {
                if(count1==1)
                {
                ctx.drawImage(img1,0,0);

                }
            
            
            
            if(count1==2)
            {
                ctx.drawImage(img1,0,0);
                ctx.drawImage(img2,x,y,w,h);
                
                //var showimage=document.getElementById('imgid');
                //showimage.src=dataURL;
                //showimage.crossOrigin = "Anonymous";
                var sikandar=1;
                
               

            }


        }
    
      

        
            $( document ).ready(function() {
                if(document.getElementById('setp').value)
                        {
                        var form=document.getElementById('btn1');
                        form.click();
                            
                        }
                        setTimeout(arguments.callee, 600);

            });
    

            $( document ).ready(function() {
                 $("button[name='add-to-cart']").prop("type", "button");

                 $("button[name='add-to-cart']").click(function(){
                    var can=document.getElementById('canvas');
                    var dataURL=can.toDataURL();
                    var tex1=document.getElementById('img_id');
                    tex1.value=dataURL;
                    var btn4=document.getElementById('btn4');
                    btn4.click();
                    '<?php 

                         global $product;
                        $id = $product->get_id();
                    WC()->cart->add_to_cart($id );
                    $_SESSION['product_id']=$id;
                    $_SESSION['ig']=1;

                     ?>'
                    
                 });



            });
    
        





    
</script>