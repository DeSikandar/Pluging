

<?php
echo '<h3>Photo Size</h3>';
woocommerce_wp_text_input(
    array(
        'id' => 'xvalue',
        'placeholder' => 'Enter x :',
        'label' => __('X (px) :', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    )
);
woocommerce_wp_text_input(
    array(
        'id' => 'yvalue',
        'placeholder' => 'Enter y :',
        'label' => __('Y (px) :', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    )
);
woocommerce_wp_text_input(
    array(
        'id' => 'wvalue',
        'placeholder' => 'Enter w :',
        'label' => __('Width (px) :', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    )
);
woocommerce_wp_text_input(
    array(
        'id' => 'hvalue',
        'placeholder' => 'Enter h :',
        'label' => __('Height (px) :', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array(
            'step' => 'any',
            'min' => '0'
        )
    )
);



?>