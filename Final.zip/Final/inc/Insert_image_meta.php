



<?php 







add_action('woocommerce_process_product_meta', 'save_datas');


function save_datas($post_id)
{
        // Custom x field
          update_post_meta($post_id,'img_url',esc_attr($image));

             


}













?>