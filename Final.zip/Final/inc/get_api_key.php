<?php
global $wpdb;

if(isset($_POST['btnsave']))
{
       

        $table_name = $wpdb->prefix . 'sp';
        $public_id = stripslashes_deep($_POST['public_id']);
	  
	
	
	
	$wpdb->insert( 
		$table_name, 
			array(
			'name'=>$public_id
			)
		);
        
    
}
if(isset($_POST['btnupdate']))
{
	
	$public_id=$_POST['public_id'];
    global $wpdb;
    $table_name  = $wpdb->prefix."sp";

    $wpdb->query( $wpdb->prepare("UPDATE $table_name 
                SET name = %s ",$public_id)
	);
	
}

$table_name = $wpdb->prefix . 'sp';
$res= $wpdb->get_results("SELECT name  FROM $table_name");

//print_r($res[0]->name);
$public= $res[0]->name; 




?>

<div class="container">
    <form action="" method="POST" onsubmit=" return validate();">
    <label for="public_id">Enter Upload Care id</label>
    <input type="text" id="public_id" value="<?php echo $public ;  ?>" name="public_id" placeholder="Entre Api key here">
	<button type="submit" id="btn2" name="btnsave">Save</button>
	<button type="button" onclick="edit()" id="btn3">Edit</button>
	    

    </form>
	
	
</div>

<script>



		var a=document.getElementById('public_id');
		if(a.value)
		{
		
			var btn2=document.getElementById('btn2');
			btn2.innerHTML='Update';
			btn2.name="btnupdate";
			a.readOnly=true;

		}else{
			var btn2=document.getElementById('btn2');
			btn2.innerHTML='Save';
			btn2.name="btnsave";
			document.getElementById('btn2').style.visibility='visible';
			document.getElementById('btn3').style.visibility='hidden';

		}
		function edit(){
			
			document.getElementById('public_id').readOnly=false;
			document.getElementById('btn2').style.visibility='visible';
			document.getElementById('btn3').style.visibility='hidden';
			
		}

	function validate()
	{
		if(document.getElementById('public_id').value=="" ||document.getElementById('public_id').value==null )
		{
			alert("Please Enter public key");
			return false;
		}
	}
	</script>


