<?php
/**
 * Plugin Name: Photo Frame
 * Plugin URI: https://sikandar.ga/
 * Description: Add Photo to your frame.
 * Version: 1.0.0
 * Author: Sikandar
 * Author URI: https://sikandar.ga
 * Text Domain: Sikandar
 * 
 * @package PhotoFr
 */
define('plugin_path',plugin_dir_path(__FILE__));
define('plugin_url',plugins_url());
define('plugin_version','1.0.0');




add_action('admin_menu','my_admin_menu');

function my_admin_menu()
{
    //parameters details
	 //add_management_page( $page_title, $menu_title, $capability,$menu_slug, $function );
 //add a new setting page udner setting menu
//add_management_page('Footer Text', 'Footer Text', 'manage_options',__FILE__, //'footer_text_admin_page');
//add new menu and its sub menu 
    add_menu_page('Photo Frame','API Setting','manage_options','photo_frame','Get_api','dashicons-hammer',10);
   
}

function Get_api()
{
    include_once plugin_path."/inc/get_api_key.php";
}

add_action('woocommerce_product_options_general_product_data','my_product_general');

function my_product_general()
{
    include_once plugin_path."/inc/get_the_variable.php";
    
}


//add the product data to database
add_action('woocommerce_process_product_meta', 'save_data');


function save_data($post_id)
{
        // Custom x field
            $x = $_POST['xvalue'];
            if (!empty($x))
                update_post_meta($post_id, 'xvalue', esc_attr($x));
        // Custom y field
            $y = $_POST['yvalue'];
            if (!empty($y))
                update_post_meta($post_id, 'yvalue', esc_attr($y));

        // Custom w field
            $w = $_POST['wvalue'];
            if (!empty($w))
                update_post_meta($post_id, 'wvalue', esc_attr($w));

        // Custom h field
            $h = $_POST['hvalue'];
            if (!empty($h))
                update_post_meta($post_id, 'hvalue', esc_attr($h));

             


}

//update the postmeta
add_action('pre_post_update','update_data');

function update_data($post_id)
{
    // Custom x field
        $x = $_POST['xvalue'];
        if (!empty($x))
            update_post_meta($post_id, 'xvalue', esc_attr($x));
    // Custom y field
        $y = $_POST['yvalue'];
        if (!empty($y))
            update_post_meta($post_id, 'yvalue', esc_attr($y));

    // Custom w field
        $w = $_POST['wvalue'];
        if (!empty($w))
            update_post_meta($post_id, 'wvalue', esc_attr($y));

    // Custom h field
        $h = $_POST['hvalue'];
        if (!empty($h))
            update_post_meta($post_id, 'hvalue', esc_attr($y));

   


}

//add_action( 'woocommerce_product_options_general_product_data', 'woocommerce_product_custom_fields' );


//add button
function Button_image()
{
    include_once plugin_path."/inc/button_defi.php";
  //  echo "<button type=reset>TEst</button>";
}


//testin on image
//add_action( 'woocommerce_product_thumbnails', 'imafag', 20 );
//function imafag()
//{
  //  echo "this is the image";
    //echo "<style>img{ visibile:none; }</style>";
    //echo "<img src='http://localhost/wordpres/wp-content/uploads/2018/09/fr.png' >";
//}


function remove_single_product_image( $html, $thumbnail_id ) {
    return '';
}
//create the canvas
function add_single_product_image($html,$thumbnail_id)
{
    include_once plugin_path."/inc/get_canvas.php";
    //echo "<canvas style='border:2px solid green;' id=>Not support</canvas>";
    //echo "this is workin";
    
  
}



add_action( 'woocommerce_before_main_content', 'bbloomer_single_product_pages' );
 
function bbloomer_single_product_pages() {
     global $post;
    $terms = wp_get_post_terms( $post->ID, 'product_cat' );
    foreach ( $terms as $term ) $categories[] = $term->slug;

    if ( in_array( 'electronic', $categories ) ) {
   // echo 'In audio';

    add_filter( 'woocommerce_single_product_image_thumbnail_html', 'remove_single_product_image', 10, 2 );
    add_filter( 'woocommerce_single_product_image_thumbnail_html', 'add_single_product_image', 10, 2 );
    add_action('woocommerce_before_add_to_cart_button','Button_image', 10);
    add_filter( 'woocommerce_cart_item_thumbnail', '__return_false' );

    add_filter('woocommerce_cart_item_thumbnail','cart_imgag');    
    //woocommerce_get_template_part( 'content', 'single-product' );
    }
 
}




register_activation_hook( __FILE__, 'create_database' );
//create gloabel variabale
global $photo_frame_version;
$photo_frame_version = '1.0';
//creat table at time actionavation
function create_database()
{       global $wpdb;
        global $photo_frame_version;

        $table_name = $wpdb->prefix . 'sp';
        $table_name2=$wpdb->prefix. 'sp2';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            name tinytext NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        
        $sql1 = "CREATE TABLE IF NOT EXISTS $table_name2 (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            text text NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate;";
        

        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
        dbDelta( $sql1 );

        add_option( 'photo_frame_version', $photo_frame_version );



        add_action( 'activated_plugin', 'cyb_activation_redirect' );
        
    
        

}

function cyb_activation_redirect( $plugin ) {
    if( $plugin == plugin_basename( __FILE__ ) ) {
        exit( wp_redirect( admin_url( 'admin.php?page=photo_frame' ) ) );
    }
}


//put the javascript key at header
add_action('init','add_to_header');

function add_to_header()
{
   
    wp_enqueue_script(
        "cpl_scripts",
        plugin_url."/Final/assets/js/uploadcare.full.min.js",
        '',
        plugin_version,
        false

    );

    wp_enqueue_style(
        "cpl_style",
        plugin_url."/Final/assets/css/main.css",
        '',
        plugin_version
        

    );
    wp_enqueue_script(
        "cpl_scriptjs",
        plugin_url."/Final/assets/js/jquery-3.3.1.min.js",
        '',
        plugin_version,
        false

    );

     wp_enqueue_script(
        "cpl_scripjs",
        plugin_url."/Final/assets/js/jquery.session.js",
        '',
        plugin_version,
        false

    );
    wp_enqueue_script(
        "cpl_script",
        plugin_url."/Final/assets/js/customscript.js",
        '',
        plugin_version,
        false

    );


    
    

}

//add to header tag
add_action('wp_head', 'headers_add');
function headers_add(){
    //include_once plugin_path."/inc/connection.php";
    global $wpdb;
    $table_name = $wpdb->prefix . 'sp';
    $res= $wpdb->get_results("SELECT name  FROM $table_name");
   
    //print_r($res[0]->name);
    $public= $res[0]->name; 
    
?>
    <script>
        
        UPLOADCARE_PUBLIC_KEY='<?php echo $public; ?>';

    </script>
<?php
}

//start session
function boot_session() {
    session_start();
  }
  add_action('wp_loaded','boot_session');

//on deactive delete the table
register_deactivation_hook( __FILE__, 'delete_database' );
function delete_database()
{
        global $wpdb;
        global $photo_frame_version;

        $table_name = $wpdb->prefix . 'sp';
        $table_name2=$wpdb->prefix. 'sp2';
       
        $sql = "DROP TABLE IF EXISTS $table_name;";
        $sql2="DROP TABLE IF EXISTS $table_name2;";
        $wpdb->query($sql);
        $wpdb->query($sql2);
        delete_option("photo_frame_version");


}

//get image url
add_filter('woocommerce_checkout_fields','custom_override_checkout_fields');

function custom_override_checkout_fields( $fields ) {
    $fields['billing']['billing_phone_new'] = array(
       'label'     => __('Phone 2', 'woocommerce'),
        'placeholder'  => _x('Phone 2', 'placeholder', 'woocommerce'),
        'required'  => false,
        
        'class'     => array('form-row-wide'),
        'clear'     => true
    );

    return $fields;
}

//update metat
add_action( 'woocommerce_checkout_update_order_meta', 'my_custom_checkout_field_update_order_meta' );

function my_custom_checkout_field_update_order_meta( $order_id ) {
    if ( ! empty( $_POST['billing_phone_new'] ) ) {
        update_post_meta( $order_id, 'billing_phone_new', sanitize_text_field( $_POST['billing_phone_new'] ) );
    }
}


function cart_imgag()
{
    
    $img=get_post_meta($product_id,'pimg_url',true); 
    echo "<img src=$img  >";



    

}



?>