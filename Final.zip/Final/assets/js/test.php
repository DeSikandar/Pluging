<?php

$a="sikandar";

?>

<script>
var b='<?php echo $a; ?>';
alert(b);    
</script>